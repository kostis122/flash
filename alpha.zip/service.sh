sleep 70
rm -rf /data/adb/modules/YJYC_YU
# [非本人允许使用此模块 修改此文字 二改倒卖盗用此模块] 者死全家