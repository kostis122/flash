Hideapp='{"configVersion":90,"detailLog":false,"maxLogSize":256,"forceMountData":true,"templates":{"白名单":{"isWhitelist":true,"appList":["com.tencent.mm","com.android.cts.priv.ctsshim","com.android.federatedcompute.services","com.android.uwb.resources","com.android.virtualmachine.res","com.google.android.ext.services","com.android.health.connect.backuprestore","com.android.adservices.api","com.android.healthconnect.controller","com.android.safetycenter.resources","com.android.connectivity.resources","com.android.compos.payload","com.android.rkpdapp","com.android.wifi.resources","com.android.bluetooth","com.android.networkstack.tethering","com.android.ondevicepersonalization.services","com.android.nearby.halfsheet","com.android.hotspot2.osulogin","com.android.cts.ctsshim","com.android.sdksandbox","com.android.microdroid.empty_payload","com.miui.qr","com.android.devicelockcontroller","com.unionpay.tsmservice.mi","com.mediatek.ims","com.miui.powerkeeper","com.miui.contentextension","com.android.internal.display.cutout.emulation.corner","com.android.dynsystem","com.android.internal.display.cutout.emulation.double","com.android.providers.telephony","com.android.providers.calendar","com.miui.contentcatcher","android.miui.home.launcher.res","com.mediatek.telephony","com.android.internal.systemui.navbar.gestural_wide_back","com.milink.service","com.google.android.ext.shared","com.android.networkstack.tethering.overlay","com.google.android.onetimeinitializer","com.mediatek.location.lppe.main","miui.systemui.plugin","com.mediatek.SettingsProviderResOverlay","com.mobiletools.systemhelper","com.xiaomi.cameratools","com.xiaomi.account","com.android.wallpapercropper","com.android.provision.resource.overlay","com.bsp.catchlog","com.android.providers.telephony.overlay.miui","com.xiaomi.bluetooth.rro.device.config.overlay","com.android.networkstack.tethering.inprocess.overlay","com.xiaomi.mi_connect_service","com.xiaomi.micloud.sdk","com.miui.packageinstaller","com.goolge.android.wifi.resources.xiaomi","com.android.companiondevicemanager","com.android.wifi.resources.overlay","com.android.thememanager.customthemeconfig.config.overlay","com.android.externalstorage","com.miui.securityadd","com.mediatek.ygps","com.xiaomi.gamecenter.sdk.service","com.android.htmlviewer","com.miui.extraphoto","com.android.quicksearchbox","com.mediatek.cellbroadcastuiresoverlay","com.android.mms.service","com.miui.settings.rro.device.systemui.overlay","com.xiaomi.payment","com.google.android.networkstack.tethering.overlay","com.mediatek.engineermode","com.mediatek.omacp","com.android.networkstack.inprocess.overlay","com.android.settings.overlay.miui","com.miui.tsmclient","com.miui.backup","com.google.android.configupdater","com.android.networkstack","com.newcall","com.android.vending","com.android.pacprocessor","com.android.simappdialog","com.miui.notification","com.android.networkstack.overlay","com.xiaomi.ab","com.miui.system.overlay","com.miui.micloudsync","com.xiaomi.barrage","com.android.internal.display.cutout.emulation.hole","com.android.internal.display.cutout.emulation.tall","com.miui.daemon","com.android.camera.overlay","com.android.modulemetadata","com.android.contacts","com.android.certinstaller","com.android.carrierconfig","com.android.wifi.dialog","com.android.internal.systemui.navbar.threebutton","com.google.android.marvin.talkback","com.android.carrierconfig.overlay.miui","com.miui.settings.rro.device.hide.statusbar.overlay","android.miui.overlay","com.android.stk","com.miui.vsimcore","com.android.ons","com.miui.securitycore","com.android.nfc","com.android.mtp","com.miui.carlink","com.miui.uireporter","com.android.mms","com.mediatek.mdmlsample","com.android.backupconfirm","com.miui.system","com.xiaomi.simactivate.service","com.android.statementservice","com.xiaomi.registration","com.xiaomi.touchservice","com.miui.phrase","com.miui.otaprovision","com.android.provision","com.android.overlay.systemui","com.mediatek.smartratswitch.service","com.android.settings.intelligence","com.mediatek.frameworkresoverlay","com.android.managedprovisioning.overlay","com.android.overlay.gmscontactprovider","com.miui.miwallpaper.overlay.customize","com.debug.loggerui","com.android.overlay.gmssettingprovider","com.android.internal.systemui.navbar.gestural_extra_wide_back","com.miui.systemui.devices.overlay","com.android.systemui.accessibility.accessibilitymenu","com.mediatek.miravision.ui","com.miui.aod","com.miuix.editor","com.miui.cit","com.miui.rom","com.android.sharedstoragebackup","com.mediatek.batterywarning","com.xiaomi.location.fused","com.android.dreams.basic","com.android.printspooler","com.miui.personalassistant","com.miui.misound","org.ifaa.aidl.manager","com.xiaomi.phone.overlay","com.mediatek","com.android.incallui","com.android.bips","com.android.systemui.gesture.line.overlay","com.fido.asm","com.miui.bugreport","com.android.se","com.android.inputdevices","com.newcall.overlay.miui","com.android.fileexplorer","com.miui.voicetrigger","com.xiaomi.macro","com.android.musicfx","com.android.systemui.overlay.miui","com.android.inputsettings.overlay.miui","com.google.android.overlay.gmsconfig","com.xiaomi.digitalkey","com.wapi.wapicertmanager","com.xiaomi.aiasst.service","com.miui.face","com.miui.home","com.miui.core","com.mediatek.gbaservice","com.miui.settings.rro.device.config.overlay","com.android.stk.overlay.miui","com.android.internal.systemui.navbar.gestural_narrow_back","com.android.providers.contacts","com.android.captiveportallogin","com.android.wallpaperpicker","com.android.settings.resource.overlay","com.lbe.security.miui","com.xiaomi.security.onetrack","com.miui.mediaviewer","com.android.traceur","wallpaper.xiaomi.overlay","com.android.thememanager","com.google.android.cellbroadcastreceiver.overlay.miui","com.android.wifi.resources.xiaomi","com.android.bluetoothmidiservice","com.miui.core.internal.services","com.android.systemui","com.android.internal.systemui.navbar.gestural","com.android.location.fused","com.google.android.gms.location.history","com.mediatek.voiceunlock","com.miui.greenguard","com.android.emergency","com.android.providers.userdictionary","com.android.overlay.gmstelecomm","com.miui.screenshot","com.android.wifi.system.resources.overlay","com.android.providers.blockednumber","com.android.wallpaperbackup","com.android.shell","com.android.overlay.gmstelephony","com.android.phone","com.miui.voiceassist","android.miui.overlay.telephony","com.miui.systemui.overlay.devices.android","com.android.vpndialogs","com.miui.accessibility","com.miui.systemui.carriers.overlay","com.miui.yellowpage","com.miui.voiceassistoverlay","com.miui.misightservice","com.mediatek.lbs.em2.ui","com.modemdebug","com.mediatek.mdmconfig","com.google.android.networkstack.overlay","com.android.settings","org.mipay.android.manager","com.android.storagemanager","com.miui.analytics","com.google.android.cellbroadcastservice.overlay.miui","com.xiaomi.metoknlp","com.xiaomi.bluetooth","com.android.systemui.navigation.bar.overlay","com.miui.securityinputmethod","com.miui.miwallpaper","com.miui.settings.rro.device.type.overlay","com.android.apps.tag","com.trustonic.teeservice","com.android.wallpaper.livepicker","com.mediatek.voicecommand","com.android.networkstack.overlay.miui","com.android.role.notes.enabled","com.android.providers.partnerbookmarks","com.xiaomi.ugd","com.mediatek.callrecorder","com.xiaomi.mtb","com.xiaomi.mis","com.xiaomi.aon","com.miui.touchassistant","com.sohu.inputmethod.sogou.xiaomi","com.google.android.accessibility.switchaccess","com.miui.audiomonitor","com.xiaomi.otrpbroker","com.xiaomi.gnss.polaris","com.google.android.documentsui","com.tencent.soter.soterserver","com.mediatek.capctrl.service","android.aosp.overlay.telephony","com.mediatek.atci.service","com.miui.cloudservice","com.android.managedprovisioning","com.xiaomi.mirror","com.google.android.printservice.recommendation","com.xiaomi.misettings","com.android.phone.overlay.miui","com.miui.miwallpaper.config.overlay","com.android.overlay.cngmstelecomm","com.android.providers.settings.overlay","com.miui.wmsvc","com.miui.nextpay","com.android.internal.systemui.navbar.transparent","com.android.wifi.system.mainline.resources.overlay","com.android.intentresolver","com.android.internal.display.cutout.emulation.waterfall","com.xiaomi.joyose","com.android.proxyhandler","com.mediatek.FrameworkResOverlayExt","com.android.theme.font.notoserifsource","com.android.credentialmanager","com.xiaomi.finddevice","com.miui.wallpaper.overlay.customize","com.android.carrierdefaultapp","com.android.localtransport","com.xiaomi.xmsfkeeper","com.android.cameraextensions","com.cmcc.dcservice","com.miui.freeform","android.aosp.overlay","com.google.android.gsf","com.android.calllogbackup","com.miui.mishare.connectivity","com.google.android.gms","com.xiaomi.xmsf","com.xiaomi.aicr","com.android.camera","com.android.keychain","mark.via","com.google.android.overlay.modules.ext.services.cn","com.android.cellbroadcastservice","com.android.server.telecom.overlay.miui","com.android.bluetooth.overlay","com.android.server.telecom","com.android.overlay.gmssettings","com.android.cellbroadcastreceiver","com.miui.cloudbackup","com.novatek.novavis","com.mfcloudcalculate.networkdisk","com.miui.notes","com.tencent.tmgp.pubgmhd","com.miui.calculator","com.miui.cleanmaster","com.android.soundrecorder","com.miui.screenrecorder","com.android.calendar","com.miui.thirdappassistant","com.android.deskclock","com.miui.weather2","com.duokan.phone.remotecontroller","com.xiaomi.mibrain.speech","com.miui.gallery","cn.wps.moffice_eng.xiaomi.lite","com.miui.mediaeditor","com.miui.newmidrive","com.iflytek.inputmethod.miui","com.xiaomi.market","com.miui.compass","com.tencent.mobileqq","com.miui.securitycenter"]}},"scope":{"icu.nullptr.applistdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"io.github.vvb2060.mahoshojo":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.minitech.miniworld":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.byxiaorun.detector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.netease.party":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.lianghaocheng.muknightjourneyd":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.tianyu.wscq":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.tmgp.sgamece":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"io.github.vvb2060.keyattestation":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"world.letsgo.booster.android.pro":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.wemade.mirmglobal":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.ViewPassion.Evermoon":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.esunbank":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.netease.g104.cn":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.duoduo.tuanzhang":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.eg.android.AlipayGphone","com.tencent.mm"]},"com.playmini.miniworld":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"io.github.huskydg.memorydetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.sup.android.superb":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"zhs.betale.ccCallBlockerN":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.tmgp.sgame":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.zyqw.mnqzjy.ewan":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.miniworldroyale.sparkgame.aligames":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.network.tools.fast.vpn":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"tv.danmaku.bili":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"tv.danmaku.bilibilihd":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"eco.tachyon.android":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.sankuai.meituan":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.okinc.okex.gp":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.kk.game.booster.fast":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.iflytek.inputmethod.custom":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"zwkj.twlw":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.miniworldroyale.sparkgame"]},"com.miniworldroyale.sparkgame":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.ngame.allstar.eu":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.twwrwyyyd.ynzi":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.tmgp.sgame"]},"com.sirius.entropy":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.tmgp.sgame"]},"com.tencent.ngame.chty":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.dy.wzbxz.huawei":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.lolm":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.gamehelper.smoba":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.tmri.app.main":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.tmgp.pubgmhd":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.levelinfinite.sgameGlobal":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.zhenxi.hunter":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.mf.uam":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.dearu.bubble.jyp":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"cn.jj.log":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.daofeng.zuhaowan":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.minitech.miniworld.vivo":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.yitong.mbank.psbc":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.happyelements.AndroidAnimal":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mm","com.tencent.mobileqq"]},"com.tencent.tmgp.cf":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.mm"]},"com.tencent.cmocmna":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":["com.tencent.mobileqq","com.tencent.tmgp.sgame","com.tencent.mm"]},"icu.nullptr.nativetest":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.aidlux":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.letsgo":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.netease.frxy":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.mnqzjy.bzgame.bazhang":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.upgadata.up7723"]},"com.devsisters.ck":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.chinalife.ebz":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.sunboxsoft.charge.institute":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.dalianboyou.zhk":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.tencent.tmgp.sgame"]},"com.netease.cloudmusic":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.ccb.longjiLife":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.igame":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.tencent.tmgp.sgame"]},"krypton.tbsafetychecker":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名\n单"],"extraAppList":["com.tsng.applistdetector"]},"useWhitelist":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名\n单"],"extraAppList":[]},"com.unicom.wopay":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名\n单"],"extraAppList":[]},"com.tencent.tmgp.dnf":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.kurogame.mingchao":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.pubg.newstate":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.sankuai.meituan.dispatch.crowdsource":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tencent.tmgp.trssj":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.fantasytat.propdor":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.ztgame.bob":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.chinaunicom.zst":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.youhu.laifu":{"useWhitelist":true,"excludeSystemApps":false,"applyTemplates":["白名单"],"extraAppList":[]},"me.garfieldhan.holmes":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"com.tsng.applistdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"luna.safe.luna":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":["com.android.internal.systemui.navbar.threebutton","com.android.safetycenter.resources","com.android.internal.display.cutout.emulation.corner","com.android.providers.blockednumber","com.android.internal.display.cutout.emulation.hole","com.android.incallui","com.android.phone","com.miui.powerkeeper","com.android.managedprovisioning","com.android.dreams.basic","com.google.android.accessibility.switchaccess","com.android.provision","com.android.keychain","com.android.companiondevicemanager","com.android.internal.display.cutout.emulation.waterfall","com.android.captiveportallogin","com.xiaomi.location.fused","com.android.inputdevices","com.baidu.input_mi","com.miui.securitycenter","com.ss.android.ugc.aweme","com.miui.calculator","com.android.browser","com.android.settings","com.android.thememanager"]},"io.github.vvb2060.magiskdetector":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]},"gr.nikolasspyr.integritycheck":{"useWhitelist":true,"excludeSystemApps":true,"applyTemplates":["白名单"],"extraAppList":[]}}}'
Old_hideapp="/data/user/0/com.tsng.pzyhrx.hma/files/config.json"
echo "\n
**********************************************
欢迎使用 咸鱼玩家*云端那边* 制作的一键隐藏脚本! \n
**********************************************"

random_str=$(LC_ALL=C tr -dc 'a-z' < /dev/urandom | head -c 6)

first_char=$(echo "$random_str" | cut -c1)
two_chars=$(echo "$random_str" | tail -c3)
password="$first_char$two_chars"

echo "请输入 ($random_str) 以确认，输入其他内容以取消："
read -r MiMa
if [[ "$MiMa" != "$password" ]]; then
    echo "取消操作"
    exit 0
fi

if [ -d "/data/adb/magisk" ]; then
    mask_cmd="magisk --install-module"
elif [ -d "/data/adb/ksu" ]; then
    mask_cmd="ksud module install"
elif [ -d "/data/adb/ap" ]; then
    mask_cmd="apd module install"
else
    echo "未检测到面具, 请手动选择"
    echo "1-------------alpha"
    echo "2-------------ksu_next"
    echo "3-------------aptch"
    read input

    if [ "$input" = "1" ]; then
        mask_cmd="magisk --install-module"
    elif [ "$input" = "2" ]; then
        mask_cmd="ksud module install"
    elif [ "$input" = "3" ]; then
        mask_cmd="apd module install"
    else
        echo "无效输入，退出"
        exit 1
    fi
fi

MODULE_DIR="/storage/emulated/0/hide/zip"
for Zip1 in "$MODULE_DIR"/*.zip; do
    if [ -f "$Zip1" ]; then
        echo "正在刷入模块: $Zip1"
        $mask_cmd "$Zip1"
        if [ $? -eq 0 ]; then
            echo "模块 $Zip1 刷入成功。"
        else
            echo "模块 $Zip1 刷入失败。"
        fi
    fi
    sleep 0.3
done



tmp="/data/local/tmp"
APK_DIR="/storage/emulated/0/hide/apk"
for apk in "$APK_DIR"/*.apk; do
    if [ -f "$apk" ]; then
        cp "$apk" "$tmp/"
    else
        echo "$apk 不存在或者不是文件"
    fi
done

for apk in "$tmp"/*.apk; do
    if [ -f "$apk" ]; then
        echo "正在安装: $apk"
        if pm install "$apk"; then
            echo "$apk 安装成功"
        else
            echo "$apk 安装失败"
        fi
        rm "$apk"
    else
        echo "$apk 不存在或者不是文件"
    fi
done


echo "隐藏应用列表\n"
am start com.tsng.pzyhrx.hma/icu.nullptr.hidemyapplist.ui.activity.MainActivity
sleep 2
am start bin.mt.plus/bin.mt.plus.Main
am start bin.mt.plus.canary/bin.mt.plus.Main
sleep 0.3
echo "$Hideapp" > "$Old_hideapp"
sleep 0.3


echo "哈希值配置\n"
vbmeta_digest=$(getprop ro.boot.vbmeta.digest 2>/dev/null)

# 检查是否成功获取哈希值
if [ -z "$vbmeta_digest" ]; then
    echo -e "无法直接从当前设备获取哈希值！"
    echo -e "\n手动获取哈希值的方法：\n①、挂VPN \n②、打开密钥认证1.6.1 \n③、找到verifiedBootHash \n④、复制verifiedBootHash值，并粘贴到脚本中"
    
    echo -n -e "请手动输入哈希值: "
    read -r vbmeta_digest
fi

# 清理输入，删除所有非字母和数字的字符
cleaned_digest=$(echo "$vbmeta_digest" | tr -d '[:punct:]' | tr -d ' ' | tr -d '\n' | tr -d '\r')

# 检查清理后的输入是否为空
if [ -z "$cleaned_digest" ]; then
    echo -e "错误：输入的哈希值不能为空！"
    exit 1
fi

# 转换为大写
cleaned_digest_upper=$(echo "$cleaned_digest" | tr '[:lower:]' '[:upper:]')

# 检查清理后的字符长度是否为64
if [ "${#cleaned_digest_upper}" -ne 64 ]; then
    echo -e "错误：输入的哈希值必须包含 64 个字符！当前字符数为：${#cleaned_digest_upper}"
    exit 1
fi

# 打印当前设备哈希值
echo -e "\n当前设备哈希值为：$cleaned_digest_upper\n"

# 创建目录和属性文件
PROP_FILE_PATH="/data/adb/modules/haxizhi"
SERVICE_FILE="$PROP_FILE_PATH/service.sh"
MODULE_FILE="$PROP_FILE_PATH/module.prop"

mkdir -p "$PROP_FILE_PATH"
{
    echo "#!/system/bin/sh"
    echo "resetprop -n ro.boot.vbmeta.digest $cleaned_digest_upper"
} > "$SERVICE_FILE"

{
    echo "id=yun"
    echo "name=重置哈希值"
    echo "version=V0316"
    echo "versionCode=20250316"
    echo "author=yun"
    echo "description=此模块由 咸鱼玩家*云端那边* 制作的 一键隐藏环境脚本"
} > "$MODULE_FILE"

echo -e "已自动创建 开机自动重置哈希值模块"


echo "添加密钥\n"
cp "/storage/emulated/0/hide/keybox.xml"  "/data/adb/tricky_store/keybox.xml"

echo "添加包名\n"
# 创建目标目录，如果不存在的话
mkdir -p /data/adb/tricky_store
# 获取所有第三方应用的包名并在包名结尾添加!号保存到 target.txt 文件
pm list packages -3 | sed 's/package://g' | sed 's/$/!/g' > /data/adb/tricky_store/target.txt
# 显示结果
cat /data/adb/tricky_store/target.txt

# echo "切换白名单\n"
# whitelist="/data/adb/shamiko/whitelist"
# if [ ! -f "$whitelist" ]; then
#     echo "正在切换为白名单模式"
#     touch "$whitelist"
#     echo "切换完成"
# fi


echo "执行完毕!现在开始最终清理......"
sleep 0.3

mv "/storage/emulated/0/hide/HMA_Config.json"   "/storage/emulated/0/Download"
mv "/storage/emulated/0/hide/keybox.xml"   "/storage/emulated/0/Download"
rm -rfv "/storage/emulated/0/TWRP"

echo -e "接下来会自动重启!!!\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启\n接下来会自动重启"
