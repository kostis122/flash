#!/bin/bash
# You need to download the PHP interpreter yourself
php -c php.ini bypass.php
