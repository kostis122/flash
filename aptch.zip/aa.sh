#!/system/bin/sh
rm -rfv "/storage/emulated/0/hide"
rm -rfv "/storage/emulated/0/hide.sh"
reboot