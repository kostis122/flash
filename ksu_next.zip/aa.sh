#!/system/bin/sh
rm -rfv "/storage/emulated/0/hide"
reboot